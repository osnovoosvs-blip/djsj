# BunnyHop (Fabric 1.21.11)

Client-side mod: auto-jump + air acceleration while turning the camera. Toggle: **B**.

Build locally: `gradle build` (Gradle 9.2+, Java 21). Jar: `build/libs/`.
CI builds on every push; download the jar from Actions -> Artifacts.
